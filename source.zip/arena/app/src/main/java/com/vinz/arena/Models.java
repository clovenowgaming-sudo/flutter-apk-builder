package com.vinz.arena;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.ArrayList;
import java.util.List;

/** Mesh primitif + definisi model hero (rig bertulang) yang dibuat dari banyak bagian detail. */
public class Models {
    public static final int CUBE = 0, SPHERE = 1, CYL = 2, CONE = 3, GEM = 4, PLANE = 5;
    public static final int J_ROOT = 0, J_TORSO = 1, J_HEAD = 2, J_ARML = 3, J_ARMR = 4, J_LEGL = 5, J_LEGR = 6;
    public static final float[][] PIVOT = {
            {0, 0, 0}, {0, 1.0f, 0}, {0, 1.62f, 0}, {0, 1.5f, -0.44f}, {0, 1.5f, 0.44f}, {0, 0.92f, -0.17f}, {0, 0.92f, 0.17f}};

    public static class Mesh {
        public FloatBuffer fb; public int count; public int vbo;
    }

    public static class Part {
        public int mesh, joint;
        public float px, py, pz, sx, sy, sz, rx, ry, rz, r, g, b, glow, metal;
        public Part rot(float x, float y, float z) { rx = x; ry = y; rz = z; return this; }
        public Part glow(float v) { glow = v; return this; }
        public Part metal(float v) { metal = v; return this; }
    }

    public static class Hero {
        public String name, title, role, desc;
        public int color;
        public List<Part> parts = new ArrayList<>();
        public String[] skillNames;
        public float scale = 1f;
        public float[] aura = {1, 1, 1};
    }

    // ---------------- geometri ----------------
    private static ArrayList<Float> buf;

    private static void v(float x, float y, float z, float nx, float ny, float nz) {
        buf.add(x); buf.add(y); buf.add(z); buf.add(nx); buf.add(ny); buf.add(nz);
    }

    private static void tri(float[] a, float[] b, float[] c) {
        float ux = b[0] - a[0], uy = b[1] - a[1], uz = b[2] - a[2];
        float vx = c[0] - a[0], vy = c[1] - a[1], vz = c[2] - a[2];
        float nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
        float l = (float) Math.sqrt(nx * nx + ny * ny + nz * nz); if (l == 0) l = 1;
        nx /= l; ny /= l; nz /= l;
        v(a[0], a[1], a[2], nx, ny, nz); v(b[0], b[1], b[2], nx, ny, nz); v(c[0], c[1], c[2], nx, ny, nz);
    }

    private static void quad(float[] a, float[] b, float[] c, float[] d) { tri(a, b, c); tri(a, c, d); }

    private static float[] cubeData() {
        buf = new ArrayList<>();
        float h = 0.5f;
        float[][] p = {{-h, -h, -h}, {h, -h, -h}, {h, h, -h}, {-h, h, -h}, {-h, -h, h}, {h, -h, h}, {h, h, h}, {-h, h, h}};
        quad(p[4], p[5], p[6], p[7]); quad(p[1], p[0], p[3], p[2]);
        quad(p[5], p[1], p[2], p[6]); quad(p[0], p[4], p[7], p[3]);
        quad(p[7], p[6], p[2], p[3]); quad(p[0], p[1], p[5], p[4]);
        return toArr();
    }

    private static float[] sphereData(int st, int sl) {
        buf = new ArrayList<>();
        for (int i = 0; i < st; i++) {
            float a0 = (float) Math.PI * i / st, a1 = (float) Math.PI * (i + 1) / st;
            for (int j = 0; j < sl; j++) {
                float b0 = (float) (2 * Math.PI * j / sl), b1 = (float) (2 * Math.PI * (j + 1) / sl);
                float[] p00 = sp(a0, b0), p01 = sp(a0, b1), p10 = sp(a1, b0), p11 = sp(a1, b1);
                v(p00[0], p00[1], p00[2], p00[0] * 2, p00[1] * 2, p00[2] * 2);
                v(p10[0], p10[1], p10[2], p10[0] * 2, p10[1] * 2, p10[2] * 2);
                v(p11[0], p11[1], p11[2], p11[0] * 2, p11[1] * 2, p11[2] * 2);
                v(p00[0], p00[1], p00[2], p00[0] * 2, p00[1] * 2, p00[2] * 2);
                v(p11[0], p11[1], p11[2], p11[0] * 2, p11[1] * 2, p11[2] * 2);
                v(p01[0], p01[1], p01[2], p01[0] * 2, p01[1] * 2, p01[2] * 2);
            }
        }
        return toArr();
    }

    private static float[] sp(float a, float b) {
        return new float[]{(float) (0.5 * Math.sin(a) * Math.cos(b)), (float) (0.5 * Math.cos(a)), (float) (0.5 * Math.sin(a) * Math.sin(b))};
    }

    private static float[] cylData(int seg, float topR, float botR, boolean cone) {
        buf = new ArrayList<>();
        for (int i = 0; i < seg; i++) {
            float a0 = (float) (2 * Math.PI * i / seg), a1 = (float) (2 * Math.PI * (i + 1) / seg);
            float c0 = (float) Math.cos(a0), s0 = (float) Math.sin(a0), c1 = (float) Math.cos(a1), s1 = (float) Math.sin(a1);
            float[] b0 = {botR * c0, -0.5f, botR * s0}, b1 = {botR * c1, -0.5f, botR * s1};
            float[] t0 = {topR * c0, 0.5f, topR * s0}, t1 = {topR * c1, 0.5f, topR * s1};
            float ny = (botR - topR) * 0.5f;
            v(b0[0], b0[1], b0[2], c0, ny, s0); v(t0[0], t0[1], t0[2], c0, ny, s0); v(t1[0], t1[1], t1[2], c1, ny, s1);
            v(b0[0], b0[1], b0[2], c0, ny, s0); v(t1[0], t1[1], t1[2], c1, ny, s1); v(b1[0], b1[1], b1[2], c1, ny, s1);
            v(0, -0.5f, 0, 0, -1, 0); v(b1[0], b1[1], b1[2], 0, -1, 0); v(b0[0], b0[1], b0[2], 0, -1, 0);
            if (topR > 0) { v(0, 0.5f, 0, 0, 1, 0); v(t0[0], t0[1], t0[2], 0, 1, 0); v(t1[0], t1[1], t1[2], 0, 1, 0); }
        }
        return toArr();
    }

    private static float[] gemData() {
        buf = new ArrayList<>();
        int seg = 6;
        for (int i = 0; i < seg; i++) {
            float a0 = (float) (2 * Math.PI * i / seg), a1 = (float) (2 * Math.PI * (i + 1) / seg);
            float[] m0 = {0.5f * (float) Math.cos(a0), 0, 0.5f * (float) Math.sin(a0)};
            float[] m1 = {0.5f * (float) Math.cos(a1), 0, 0.5f * (float) Math.sin(a1)};
            tri(new float[]{0, 0.5f, 0}, m1, m0);
            tri(new float[]{0, -0.5f, 0}, m0, m1);
        }
        return toArr();
    }

    private static float[] planeData() {
        buf = new ArrayList<>();
        float h = 0.5f;
        v(-h, 0, -h, 0, 1, 0); v(-h, 0, h, 0, 1, 0); v(h, 0, h, 0, 1, 0);
        v(-h, 0, -h, 0, 1, 0); v(h, 0, h, 0, 1, 0); v(h, 0, -h, 0, 1, 0);
        return toArr();
    }

    private static float[] toArr() {
        float[] a = new float[buf.size()];
        for (int i = 0; i < a.length; i++) a[i] = buf.get(i);
        return a;
    }

    public static Mesh[] buildMeshes() {
        float[][] d = {cubeData(), sphereData(10, 16), cylData(16, 0.5f, 0.5f, false), cylData(16, 0f, 0.5f, true), gemData(), planeData()};
        Mesh[] out = new Mesh[d.length];
        for (int i = 0; i < d.length; i++) {
            Mesh m = new Mesh();
            m.count = d[i].length / 6;
            ByteBuffer bb = ByteBuffer.allocateDirect(d[i].length * 4).order(ByteOrder.nativeOrder());
            m.fb = bb.asFloatBuffer(); m.fb.put(d[i]); m.fb.position(0);
            out[i] = m;
        }
        return out;
    }

    // ---------------- hero ----------------
    private static Part P(Hero h, int mesh, int joint, float px, float py, float pz, float sx, float sy, float sz, int rgb) {
        Part p = new Part();
        p.mesh = mesh; p.joint = joint; p.px = px; p.py = py; p.pz = pz; p.sx = sx; p.sy = sy; p.sz = sz;
        p.r = ((rgb >> 16) & 255) / 255f; p.g = ((rgb >> 8) & 255) / 255f; p.b = (rgb & 255) / 255f;
        h.parts.add(p);
        return p;
    }

    /** Tubuh humanoid dasar dengan detail armor: helm, bahu, sarung tangan, sepatu, ikat pinggang. */
    private static void humanoid(Hero h, int skin, int armor, int trim, int cloth, int boots) {
        // torso: dada, perut, ikat pinggang, plat dada
        P(h, SPHERE, J_TORSO, 0, 1.38f, 0, 0.62f, 0.62f, 0.9f, armor).metal(0.5f);
        P(h, CUBE, J_TORSO, 0, 1.28f, 0, 0.5f, 0.5f, 0.78f, cloth);
        P(h, CUBE, J_TORSO, 0.02f, 1.05f, 0, 0.44f, 0.3f, 0.6f, cloth);
        P(h, CUBE, J_TORSO, 0.0f, 0.9f, 0, 0.5f, 0.1f, 0.66f, trim).metal(0.8f);
        P(h, GEM, J_TORSO, 0.27f, 0.9f, 0, 0.14f, 0.14f, 0.14f, 0xffd24a).glow(0.5f);
        P(h, CUBE, J_TORSO, 0.27f, 1.32f, 0, 0.08f, 0.44f, 0.5f, trim).metal(0.8f);
        // kepala + leher
        P(h, CYL, J_HEAD, 0, 1.56f, 0, 0.16f, 0.14f, 0.16f, skin);
        P(h, SPHERE, J_HEAD, 0, 1.78f, 0, 0.38f, 0.42f, 0.36f, skin);
        P(h, SPHERE, J_HEAD, 0.14f, 1.8f, -0.09f, 0.07f, 0.07f, 0.06f, 0x111111);
        P(h, SPHERE, J_HEAD, 0.14f, 1.8f, 0.09f, 0.07f, 0.07f, 0.06f, 0x111111);
        // bahu
        P(h, SPHERE, J_ARML, 0, 1.55f, -0.46f, 0.3f, 0.26f, 0.3f, trim).metal(0.8f);
        P(h, SPHERE, J_ARMR, 0, 1.55f, 0.46f, 0.3f, 0.26f, 0.3f, trim).metal(0.8f);
        for (int s = 0; s < 2; s++) {
            int j = s == 0 ? J_ARML : J_ARMR; float z = s == 0 ? -0.46f : 0.46f;
            P(h, CYL, j, 0, 1.28f, z, 0.17f, 0.46f, 0.17f, armor).metal(0.4f);
            P(h, CYL, j, 0, 0.98f, z, 0.15f, 0.34f, 0.15f, skin);
            P(h, CUBE, j, 0, 0.98f, z, 0.19f, 0.2f, 0.19f, trim).metal(0.8f);
            P(h, SPHERE, j, 0, 0.76f, z, 0.16f, 0.16f, 0.16f, cloth);
        }
        for (int s = 0; s < 2; s++) {
            int j = s == 0 ? J_LEGL : J_LEGR; float z = s == 0 ? -0.17f : 0.17f;
            P(h, CYL, j, 0, 0.7f, z, 0.2f, 0.46f, 0.2f, cloth);
            P(h, SPHERE, j, 0, 0.5f, z, 0.2f, 0.18f, 0.2f, trim).metal(0.8f);
            P(h, CYL, j, 0, 0.3f, z, 0.17f, 0.44f, 0.17f, boots);
            P(h, CUBE, j, 0.08f, 0.07f, z, 0.34f, 0.13f, 0.2f, boots);
        }
    }

    public static Hero[] buildHeroes() {
        Hero[] all = new Hero[5];

        // 0 Aldric - Ksatria pedang
        Hero a = new Hero(); a.name = "ALDRIC"; a.title = "Ksatria Fajar"; a.role = "FIGHTER"; a.color = 0xff4a8cff;
        a.skillNames = new String[]{"Tebasan", "Pusaran Pedang", "Lompatan Fajar"}; a.aura = new float[]{0.3f, 0.6f, 1f};
        humanoid(a, 0xf0c9a0, 0x3b6fd6, 0xf5c542, 0x23325e, 0x2a2a35);
        P(a, SPHERE, J_HEAD, 0, 1.84f, 0, 0.44f, 0.4f, 0.42f, 0xc9d3e6).metal(0.9f);          // helm
        P(a, CUBE, J_HEAD, 0.16f, 1.8f, 0, 0.14f, 0.07f, 0.34f, 0x151515);
        P(a, CONE, J_HEAD, -0.02f, 2.14f, 0, 0.1f, 0.34f, 0.1f, 0xe23b3b);                       // jambul
        P(a, CUBE, J_TORSO, -0.2f, 1.2f, 0, 0.08f, 1.0f, 0.7f, 0xc23838);                         // jubah
        P(a, CUBE, J_ARMR, 0.3f, 0.75f, 0.46f, 1.35f, 0.14f, 0.07f, 0xdfe7f5).metal(1f);         // bilah
        P(a, CUBE, J_ARMR, 0.3f, 0.75f, 0.46f, 1.35f, 0.04f, 0.1f, 0xffffff).glow(0.2f);
        P(a, CUBE, J_ARMR, 0, 0.75f, 0.46f, 0.1f, 0.18f, 0.4f, 0xf5c542).metal(1f);              // guard
        P(a, GEM, J_ARMR, 1.0f, 0.75f, 0.46f, 0.22f, 0.3f, 0.12f, 0xaee2ff).rot(0, 0, 90).glow(0.6f);
        P(a, CYL, J_ARML, 0.2f, 0.9f, -0.62f, 0.7f, 0.06f, 0.7f, 0x3b6fd6).rot(90, 0, 0).metal(0.8f); // perisai
        P(a, SPHERE, J_ARML, 0.25f, 0.9f, -0.66f, 0.16f, 0.16f, 0.1f, 0xf5c542).metal(1f);
        all[0] = a;

        // 1 Lyra - Penyihir api
        Hero b = new Hero(); b.name = "LYRA"; b.title = "Penyihir Bara"; b.role = "MAGE"; b.color = 0xffff6a3d;
        b.skillNames = new String[]{"Percik Api", "Bola Api", "Hujan Meteor"}; b.aura = new float[]{1f, 0.42f, 0.2f};
        humanoid(b, 0xf6d3b8, 0x8a2be2, 0xffc94a, 0x5a1f8f, 0x3b1a50);
        P(b, CONE, J_LEGL, -0.05f, 0.62f, 0, 0.62f, 0.95f, 0.8f, 0x6a2bb0);                         // jubah panjang
        P(b, CONE, J_HEAD, -0.05f, 2.2f, 0, 0.62f, 0.62f, 0.62f, 0x7a2bd0);                         // topi
        P(b, CYL, J_HEAD, -0.03f, 1.95f, 0, 0.78f, 0.06f, 0.78f, 0x5a1f8f);
        P(b, GEM, J_HEAD, 0.2f, 1.97f, 0, 0.1f, 0.14f, 0.1f, 0xffb347).glow(0.8f);
        P(b, CYL, J_ARMR, 0.05f, 0.9f, 0.46f, 0.07f, 2.3f, 0.07f, 0x6b3b1a);                        // tongkat
        P(b, SPHERE, J_ARMR, 0.05f, 2.1f, 0.46f, 0.3f, 0.3f, 0.3f, 0xff6a3d).glow(1f);
        P(b, GEM, J_ARMR, 0.05f, 2.1f, 0.46f, 0.5f, 0.62f, 0.5f, 0xffd08a).glow(0.7f);
        P(b, CUBE, J_TORSO, -0.2f, 1.1f, 0, 0.06f, 1.0f, 0.82f, 0xffb347);                          // selendang
        all[1] = b;

        // 2 Kael - Pemanah
        Hero c = new Hero(); c.name = "KAEL"; c.title = "Mata Elang"; c.role = "MARKSMAN"; c.color = 0xff3ddc84;
        c.skillNames = new String[]{"Panah Cepat", "Hujan Panah", "Bidikan Maut"}; c.aura = new float[]{0.3f, 1f, 0.55f};
        humanoid(c, 0xe0b48a, 0x2f7a4f, 0xd8c27a, 0x234d38, 0x3a2a1a);
        P(c, CONE, J_HEAD, -0.06f, 1.9f, 0, 0.56f, 0.66f, 0.56f, 0x2f7a4f).rot(0, 0, 12);          // tudung
        P(c, CUBE, J_TORSO, -0.24f, 1.25f, 0.1f, 0.14f, 0.6f, 0.2f, 0x5a3a1c);                    // quiver
        for (int i = 0; i < 3; i++) P(c, CYL, J_TORSO, -0.28f, 1.62f, 0.02f + 0.07f * i, 0.04f, 0.3f, 0.04f, 0xe8e0c0);
        P(c, CUBE, J_ARML, 0.05f, 0.76f, -0.46f, 0.07f, 0.12f, 0.12f, 0x5a3a1c);
        P(c, CUBE, J_ARML, 0.15f, 0.55f, -0.46f, 0.08f, 0.5f, 0.07f, 0x8b5a2b).rot(0, 0, -18);    // busur atas
        P(c, CUBE, J_ARML, 0.15f, 1.1f, -0.46f, 0.08f, 0.5f, 0.07f, 0x8b5a2b).rot(0, 0, 18);      // busur bawah
        P(c, CYL, J_ARML, -0.02f, 0.82f, -0.46f, 0.025f, 1.05f, 0.025f, 0xf2f2f2);                // senar
        P(c, GEM, J_ARML, 0.3f, 0.82f, -0.46f, 0.14f, 0.2f, 0.14f, 0x3ddc84).glow(0.8f);
        all[2] = c;

        // 3 Brom - Tank
        Hero d = new Hero(); d.name = "BROM"; d.title = "Benteng Gunung"; d.role = "TANK"; d.color = 0xffd9a441; d.scale = 1.18f;
        d.skillNames = new String[]{"Ayunan Palu", "Hantaman Bumi", "Gelombang Kejut"}; d.aura = new float[]{1f, 0.78f, 0.25f};
        humanoid(d, 0xd2a07a, 0x7a7f8c, 0xd9a441, 0x4a3a2a, 0x30302a);
        P(d, SPHERE, J_ARML, 0, 1.6f, -0.52f, 0.5f, 0.4f, 0.5f, 0x9aa0ae).metal(1f);
        P(d, SPHERE, J_ARMR, 0, 1.6f, 0.52f, 0.5f, 0.4f, 0.5f, 0x9aa0ae).metal(1f);
        P(d, CONE, J_ARML, 0, 1.92f, -0.52f, 0.1f, 0.25f, 0.1f, 0xd9a441);
        P(d, CONE, J_ARMR, 0, 1.92f, 0.52f, 0.1f, 0.25f, 0.1f, 0xd9a441);
        P(d, SPHERE, J_HEAD, 0, 1.86f, 0, 0.46f, 0.38f, 0.44f, 0x808795).metal(0.9f);               // helm
        P(d, CONE, J_HEAD, 0, 1.95f, -0.25f, 0.1f, 0.4f, 0.1f, 0xd9a441).rot(40, 0, 0);          // tanduk
        P(d, CONE, J_HEAD, 0, 1.95f, 0.25f, 0.1f, 0.4f, 0.1f, 0xd9a441).rot(-40, 0, 0);
        P(d, CUBE, J_HEAD, 0.17f, 1.82f, 0, 0.1f, 0.06f, 0.34f, 0x111111);
        P(d, CYL, J_ARMR, 0.0f, 0.75f, 0.46f, 0.09f, 1.3f, 0.09f, 0x5a3a1c).rot(0, 0, 90);        // gagang palu
        P(d, CUBE, J_ARMR, 0.78f, 0.75f, 0.46f, 0.5f, 0.5f, 0.7f, 0x8a909e).metal(1f);            // kepala palu
        P(d, CUBE, J_ARMR, 0.78f, 0.75f, 0.46f, 0.52f, 0.12f, 0.72f, 0xd9a441).metal(1f);
        P(d, CUBE, J_ARML, 0.3f, 0.9f, -0.66f, 0.1f, 1.0f, 0.75f, 0x6a7080).metal(0.9f);         // perisai besar
        P(d, GEM, J_ARML, 0.38f, 0.9f, -0.66f, 0.2f, 0.28f, 0.2f, 0xd9a441).rot(0, 0, 90).glow(0.4f);
        all[3] = d;

        // 4 Shade - Assassin
        Hero e = new Hero(); e.name = "SHADE"; e.title = "Bayangan Malam"; e.role = "ASSASSIN"; e.color = 0xffb44dff; e.scale = 0.98f;
        e.skillNames = new String[]{"Tikam", "Terjang Bayangan", "Badai Belati"}; e.aura = new float[]{0.7f, 0.3f, 1f};
        humanoid(e, 0xc8a284, 0x2a2a3c, 0xb44dff, 0x1c1c2a, 0x14141c);
        P(e, SPHERE, J_HEAD, -0.01f, 1.82f, 0, 0.42f, 0.46f, 0.4f, 0x1c1c2a);                       // tudung
        P(e, CUBE, J_HEAD, 0.15f, 1.78f, 0, 0.1f, 0.12f, 0.3f, 0xc8a284);
        P(e, CUBE, J_HEAD, 0.2f, 1.8f, -0.08f, 0.04f, 0.04f, 0.06f, 0xb44dff).glow(1f);
        P(e, CUBE, J_HEAD, 0.2f, 1.8f, 0.08f, 0.04f, 0.04f, 0.06f, 0xb44dff).glow(1f);
        P(e, CUBE, J_TORSO, -0.3f, 1.2f, 0, 0.06f, 0.9f, 0.5f, 0x6a2bb0);                          // syal panjang
        P(e, CUBE, J_TORSO, -0.34f, 0.7f, 0.1f, 0.06f, 0.5f, 0.2f, 0x6a2bb0).rot(0, 0, 10);
        P(e, CUBE, J_ARMR, 0.35f, 0.75f, 0.46f, 0.7f, 0.07f, 0.04f, 0xdde0ee).metal(1f);          // belati kanan
        P(e, CUBE, J_ARMR, 0.0f, 0.75f, 0.46f, 0.08f, 0.14f, 0.2f, 0xb44dff).metal(1f);
        P(e, CUBE, J_ARML, 0.35f, 0.75f, -0.46f, 0.7f, 0.07f, 0.04f, 0xdde0ee).metal(1f);         // belati kiri
        P(e, CUBE, J_ARML, 0.0f, 0.75f, -0.46f, 0.08f, 0.14f, 0.2f, 0xb44dff).metal(1f);
        P(e, GEM, J_ARMR, 0.72f, 0.75f, 0.46f, 0.1f, 0.2f, 0.06f, 0xb44dff).rot(0, 0, 90).glow(0.9f);
        P(e, GEM, J_ARML, 0.72f, 0.75f, -0.46f, 0.1f, 0.2f, 0.06f, 0xb44dff).rot(0, 0, 90).glow(0.9f);
        all[4] = e;
        return all;
    }
}
