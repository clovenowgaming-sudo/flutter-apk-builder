package com.vinz.arena;

import android.os.Handler;
import android.os.Looper;

import org.json.JSONObject;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;

public class Net {
    public interface Listener { void onMsg(JSONObject o); void onState(boolean connected, String info); }

    private final OkHttpClient http = new OkHttpClient.Builder().pingInterval(15, java.util.concurrent.TimeUnit.SECONDS).build();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private WebSocket ws;
    public volatile boolean connected;
    public Listener listener;

    public void connect(String url) {
        close();
        try {
            Request r = new Request.Builder().url(url).build();
            ws = http.newWebSocket(r, new WebSocketListener() {
                @Override public void onOpen(WebSocket w, Response resp) { connected = true; ui.post(() -> { if (listener != null) listener.onState(true, "OK"); }); }
                @Override public void onMessage(WebSocket w, String text) {
                    try {
                        final JSONObject o = new JSONObject(text);
                        ui.post(() -> { if (listener != null) listener.onMsg(o); });
                    } catch (Exception ignored) { }
                }
                @Override public void onClosed(WebSocket w, int code, String reason) { connected = false; ui.post(() -> { if (listener != null) listener.onState(false, "Terputus"); }); }
                @Override public void onFailure(WebSocket w, Throwable t, Response resp) { connected = false; final String m = String.valueOf(t.getMessage()); ui.post(() -> { if (listener != null) listener.onState(false, m); }); }
            });
        } catch (Exception e) {
            connected = false;
            if (listener != null) listener.onState(false, String.valueOf(e.getMessage()));
        }
    }

    public void send(String json) { if (ws != null && connected) ws.send(json); }

    public void send(String type, Object... kv) {
        try {
            JSONObject o = new JSONObject();
            o.put("t", type);
            for (int i = 0; i + 1 < kv.length; i += 2) o.put(String.valueOf(kv[i]), kv[i + 1]);
            send(o.toString());
        } catch (Exception ignored) { }
    }

    public void close() { if (ws != null) { try { ws.close(1000, "bye"); } catch (Exception ignored) { } ws = null; } connected = false; }
}
