// Hero Arena - server multiplayer 5v5 (authoritative). Jalankan: npm i && node server.js
const WebSocket = require('ws');
const fs = require('fs');
const PORT = process.env.PORT || 8080;
const wss = new WebSocket.Server({ port: PORT });
const DB = __dirname + '/accounts.json';
let accounts = {};
try { accounts = JSON.parse(fs.readFileSync(DB, 'utf8')); } catch (e) {}
const saveDb = () => { try { fs.writeFileSync(DB, JSON.stringify(accounts)); } catch (e) {} };

// ---------- data hero: [hp, speed, [range,r,dmg,cd,dash,melee] x3 (basic, skill1, ultimate)]
const HEROES = [
  { name: 'Aldric', hp: 1900, spd: 6.4, sk: [[2.0, 2.4, 85, 0.7, 0], [0, 4.6, 230, 6, 0], [7, 4.2, 430, 14, 7]] },
  { name: 'Lyra', hp: 1300, spd: 6.1, sk: [[9, 1.2, 95, 0.8, 0], [11, 2.6, 270, 5, 0], [11, 5.2, 540, 16, 0]] },
  { name: 'Kael', hp: 1350, spd: 6.7, sk: [[10, 1.0, 92, 0.55, 0], [11, 2.2, 250, 6, 0], [16, 1.6, 620, 15, 0]] },
  { name: 'Brom', hp: 2700, spd: 5.7, sk: [[2.0, 2.5, 66, 0.8, 0], [3, 4.2, 170, 6, 0], [0, 6.8, 320, 14, 0]] },
  { name: 'Shade', hp: 1400, spd: 7.3, sk: [[1.8, 2.2, 82, 0.5, 0], [6, 2.4, 240, 5, 6], [0, 5.2, 500, 15, 0]] },
];
const LANES = [-26, 0, 26];
const NEXUS_X = 54;
const DT = 0.05;

let nextId = 1;
const clients = new Map();   // ws -> client
const byName = new Map();
let queue = { classic: [], rank: [] };
const parties = new Map();   // code -> {leader, members:[client]}
const matches = new Set();

function rankInfo(pts) {
  const tiers = ['Bronze', 'Silver', 'Gold', 'Platinum', 'Diamond', 'Master', 'Grandmaster', 'Mythic'];
  const i = Math.min(tiers.length - 1, Math.floor(pts / 100));
  return { tier: tiers[i], stars: Math.floor((pts % 100) / 20) + 1, pts };
}
function send(c, o) { if (c && c.ws && c.ws.readyState === 1) c.ws.send(JSON.stringify(o)); }
function profile(c) {
  const a = c.acc;
  return { t: 'profile', id: c.id, name: a.name, wins: a.wins, losses: a.losses, rank: rankInfo(a.pts), friends: friendList(c), party: c.party || null };
}
function friendList(c) {
  return c.acc.friends.map(n => ({ name: n, online: byName.has(n), rank: accounts[n] ? rankInfo(accounts[n].pts).tier : '-' }));
}

wss.on('connection', ws => {
  const c = { ws, id: nextId++, acc: null, match: null, party: null, inp: { dx: 0, dz: 0, sk: 0 } };
  clients.set(ws, c);
  ws.on('message', m => { let o; try { o = JSON.parse(m); } catch (e) { return; } handle(c, o); });
  ws.on('close', () => leave(c));
  ws.on('error', () => {});
});

function leave(c) {
  clients.delete(c.ws);
  if (c.acc) { if (byName.get(c.acc.name) === c) byName.delete(c.acc.name); }
  for (const k of ['classic', 'rank']) queue[k] = queue[k].filter(g => !g.includes(c));
  if (c.party) partyLeave(c);
  if (c.match && c.hero) c.hero.bot = true; // diganti bot saat disconnect
}

function handle(c, o) {
  switch (o.t) {
    case 'login': {
      let name = String(o.name || 'Player').slice(0, 14);
      const key = o.uid ? 'u:' + o.uid : null;
      let acc = key ? Object.values(accounts).find(a => a.uid === key) : null;
      if (!acc) {
        let n = name, i = 1;
        while (accounts[n]) n = name + (++i);
        acc = accounts[n] = { name: n, uid: key, pts: 0, wins: 0, losses: 0, friends: [] };
        saveDb();
      }
      c.acc = acc; byName.set(acc.name, c);
      send(c, profile(c));
      break;
    }
    case 'profile': if (c.acc) send(c, profile(c)); break;
    case 'friend_add': {
      if (!c.acc) break;
      const n = String(o.name || '');
      if (accounts[n] && n !== c.acc.name && !c.acc.friends.includes(n)) {
        c.acc.friends.push(n); accounts[n].friends.push(c.acc.name); saveDb();
        const f = byName.get(n); if (f) send(f, profile(f));
      }
      send(c, profile(c));
      break;
    }
    case 'party_create': {
      if (c.party) partyLeave(c);
      const code = String(1000 + Math.floor(Math.random() * 9000));
      parties.set(code, { leader: c, members: [c] }); c.party = code;
      partyBroadcast(code); break;
    }
    case 'party_join': {
      const p = parties.get(String(o.code));
      if (!p || p.members.length >= 5) { send(c, { t: 'toast', m: 'Party tidak ditemukan / penuh' }); break; }
      if (c.party) partyLeave(c);
      p.members.push(c); c.party = String(o.code); partyBroadcast(c.party); break;
    }
    case 'party_leave': if (c.party) partyLeave(c); break;
    case 'invite': {
      const f = byName.get(String(o.name));
      if (f && c.party) send(f, { t: 'invite', from: c.acc.name, code: c.party });
      break;
    }
    case 'queue': {
      if (!c.acc || c.match) break;
      const mode = o.mode === 'rank' ? 'rank' : 'classic';
      const p = c.party ? parties.get(c.party) : null;
      if (p && p.leader !== c) { send(c, { t: 'toast', m: 'Hanya leader yang bisa mulai' }); break; }
      const grp = p ? p.members.slice() : [c];
      grp.forEach(g => { g.mode = mode; g.qt = Date.now(); send(g, { t: 'queued', mode }); });
      queue[mode].push(grp);
      break;
    }
    case 'unqueue':
      for (const k of ['classic', 'rank']) queue[k] = queue[k].filter(g => !g.includes(c));
      send(c, { t: 'unqueued' }); break;
    case 'pick': if (c.match && c.match.phase === 'pick' && c.hero) { c.hero.type = Math.max(0, Math.min(4, o.hero | 0)); c.hero.locked = !!o.lock; broadcastPicks(c.match); } break;
    case 'in': c.inp = { dx: +o.dx || 0, dz: +o.dz || 0, sk: o.sk | 0 }; if (c.hero && o.sk) c.hero.want = o.sk | 0; break;
    case 'exit': if (c.hero) c.hero.bot = true; c.match = null; break;
  }
}
function partyLeave(c) {
  const code = c.party; const p = parties.get(code); c.party = null;
  if (!p) return;
  p.members = p.members.filter(m => m !== c);
  if (!p.members.length) parties.delete(code);
  else { if (p.leader === c) p.leader = p.members[0]; partyBroadcast(code); }
  send(c, { t: 'party', code: null, members: [] });
}
function partyBroadcast(code) {
  const p = parties.get(code); if (!p) return;
  const members = p.members.map(m => m.acc.name);
  p.members.forEach(m => send(m, { t: 'party', code, members, leader: p.leader.acc.name }));
}

// ---------- matchmaking
setInterval(() => {
  for (const mode of ['classic', 'rank']) {
    const q = queue[mode]; if (!q.length) continue;
    const oldest = Math.min(...q.map(g => g[0].qt));
    const total = q.reduce((s, g) => s + g.length, 0);
    if (total >= 10 || Date.now() - oldest > 6000) {
      const groups = []; let cnt = 0;
      while (q.length && cnt + q[0].length <= 10) { const g = q.shift(); groups.push(g); cnt += g.length; }
      if (groups.length) createMatch(mode, groups);
    }
  }
}, 500);

function createMatch(mode, groups) {
  const m = { id: nextId++, mode, phase: 'pick', players: [], heroes: [], minions: [], towers: [], tick: 0, t: 0, pickEnd: Date.now() + 20000, waveT: 5, over: false, fx: [], ev: [], firstBlood: false };
  const teams = [[], []];
  groups.sort((a, b) => b.length - a.length);
  groups.forEach(g => { const t = teams[0].length <= teams[1].length ? 0 : 1; g.forEach(c => teams[t].push(c)); });
  for (let t = 0; t < 2; t++) {
    for (let s = 0; s < 5; s++) {
      const c = teams[t][s];
      const h = { id: nextId++, team: t, slot: s, name: c ? c.acc.name : 'Bot' + (t * 5 + s + 1), bot: !c, type: (s + t * 2) % 5, locked: !c, x: 0, z: 0, rot: t ? Math.PI : 0, hp: 1, maxhp: 1, lvl: 1, k: 0, d: 0, a: 0, mk: 0, mkT: -99, streak: 0, cd: [0, 0, 0], respawn: 0, alive: true, anim: 0, animT: 0, mm: 0, lane: s % 3, want: 0, c, tgt: null };
      if (c) { c.match = m; c.hero = h; }
      m.heroes.push(h);
    }
  }
  for (let t = 0; t < 2; t++) {
    const sg = t ? 1 : -1;
    for (let l = 0; l < 3; l++) { [20, 38].forEach((x, i) => m.towers.push({ id: nextId++, team: t, x: sg * x, z: LANES[l] * (i ? 0.85 : 1), hp: 2600 + i * 600, maxhp: 2600 + i * 600, cd: 0, nexus: false })); }
    m.towers.push({ id: nextId++, team: t, x: sg * NEXUS_X, z: 0, hp: 6000, maxhp: 6000, cd: 0, nexus: true });
  }
  matches.add(m);
  m.heroes.forEach(h => { if (h.c) send(h.c, { t: 'match', mode, you: h.id, team: h.team, players: m.heroes.map(x => ({ id: x.id, name: x.name, team: x.team, slot: x.slot, type: x.type })) }); });
  broadcastPicks(m);
}
function broadcastPicks(m) {
  const msg = { t: 'picks', picks: m.heroes.map(h => ({ id: h.id, type: h.type, lock: h.locked })) };
  m.heroes.forEach(h => h.c && send(h.c, msg));
}
function spawnHero(m, h) {
  const d = HEROES[h.type]; const lv = 1 + (h.lvl - 1) * 0.08;
  h.maxhp = d.hp * lv; h.hp = h.maxhp; h.alive = true; h.tgt = null;
  const sg = h.team ? 1 : -1;
  h.x = sg * (NEXUS_X - 6) ; h.z = (h.slot - 2) * 3.2; h.rot = h.team ? Math.PI : 0;
}
function startGame(m) {
  m.phase = 'play'; m.t = 0;
  m.heroes.forEach(h => spawnHero(m, h));
  m.heroes.forEach(h => h.c && send(h.c, { t: 'start', players: m.heroes.map(x => ({ id: x.id, name: x.name, team: x.team, slot: x.slot, type: x.type })) }));
}

// ---------- simulasi
const dist = (a, b) => Math.hypot(a.x - b.x, a.z - b.z);
function enemiesOf(m, team) {
  const list = [];
  m.heroes.forEach(h => h.alive && h.team !== team && list.push({ e: h, kind: 'h' }));
  m.minions.forEach(x => x.team !== team && list.push({ e: x, kind: 'm' }));
  m.towers.forEach(x => x.team !== team && x.hp > 0 && list.push({ e: x, kind: 't' }));
  return list;
}
function damage(m, tgt, kind, dmg, src) {
  if (kind === 't') {
    // menara kebal bila masih ada menara depan lane-nya (nexus butuh 2 menara jatuh)
    if (tgt.nexus) { const alive = m.towers.filter(t => t.team === tgt.team && !t.nexus && t.hp > 0).length; if (alive > 4) return; }
    tgt.hp -= dmg; if (tgt.hp <= 0) { tgt.hp = 0; if (tgt.nexus) endMatch(m, 1 - tgt.team); }
    return;
  }
  if (kind === 'm') { tgt.hp -= dmg; if (tgt.hp <= 0 && src && src.k !== undefined) { src.mm++; if (src.mm % 5 === 0) levelCheck(src); } return; }
  tgt.hp -= dmg;
  if (tgt.hp <= 0 && tgt.alive) killHero(m, tgt, src);
}
function levelCheck(h) { const lv = Math.min(15, 1 + Math.floor(h.k * 0.7 + h.mm / 5 + h.a * 0.3)); if (lv > h.lvl) { const r = h.hp / h.maxhp; h.lvl = lv; h.maxhp = HEROES[h.type].hp * (1 + (lv - 1) * 0.08); h.hp = h.maxhp * r; } }
function killHero(m, v, killer) {
  v.alive = false; v.hp = 0; v.d++; v.streak = 0; v.respawn = 6 + v.lvl * 0.8; v.mk = 0;
  if (killer && killer.k !== undefined) {
    killer.k++; killer.streak++;
    if (m.t - killer.mkT <= 10) killer.mk++; else killer.mk = 1;
    killer.mkT = m.t;
    const names = ['', 'SLAIN', 'DOUBLE KILL', 'TRIPLE KILL', 'MANIAC', 'SAVAGE'];
    let txt = names[Math.min(killer.mk, 5)];
    if (!m.firstBlood) { m.firstBlood = true; txt = 'FIRST BLOOD'; }
    else if (killer.mk === 1) { if (killer.streak === 3) txt = 'KILLING SPREE'; else if (killer.streak === 5) txt = 'DOMINATING'; else if (killer.streak >= 7) txt = 'LEGENDARY'; }
    m.ev.push({ t: 'kill', killer: killer.id, victim: v.id, kn: killer.name, vn: v.name, team: killer.team, txt, mk: killer.mk });
    levelCheck(killer);
  }
  m.heroes.forEach(h => { if (h.team !== v.team && h !== killer && h.alive && dist(h, v) < 18) { h.a++; levelCheck(h); } });
}
function useSkill(m, h, idx) {
  const d = HEROES[h.type]; const s = d.sk[idx]; // [range, r, dmg, cd, dash]
  if (h.cd[idx] > 0 || !h.alive) return false;
  const scale = 1 + (h.lvl - 1) * 0.08;
  const reach = s[0] + s[1];
  // auto-aim ke musuh terdekat dalam jangkauan
  let best = null, bd = 1e9;
  enemiesOf(m, h.team).forEach(o => { const dd = dist(h, o.e); const pr = o.kind === 'h' ? dd - 2 : dd; if (dd <= reach + 1.5 && pr < bd) { bd = pr; best = o.e; } });
  if (idx === 0 && !best) return false;
  if (best) h.rot = Math.atan2(best.z - h.z, best.x - h.x);
  let cx = h.x + Math.cos(h.rot) * s[0], cz = h.z + Math.sin(h.rot) * s[0];
  if (idx === 0 && s[0] > 3 && best) { cx = best.x; cz = best.z; }   // basic jarak jauh kena target
  if (idx > 0 && s[0] > 3 && best && !s[4]) { const k = Math.min(s[0], dist(h, best)); cx = h.x + Math.cos(h.rot) * k; cz = h.z + Math.sin(h.rot) * k; }
  if (s[4]) { h.x = Math.max(-58, Math.min(58, h.x + Math.cos(h.rot) * s[4])); h.z = Math.max(-36, Math.min(36, h.z + Math.sin(h.rot) * s[4])); cx = h.x; cz = h.z; }
  h.cd[idx] = s[3]; h.anim = 1 + idx; h.animT = idx === 0 ? 0.35 : 0.7;
  m.fx.push({ id: h.id, s: idx, h: h.type, x: +cx.toFixed(1), z: +cz.toFixed(1), r: s[1], rot: +h.rot.toFixed(2), team: h.team });
  const dmg = s[2] * scale;
  enemiesOf(m, h.team).forEach(o => { if (Math.hypot(o.e.x - cx, o.e.z - cz) <= s[1] + (o.kind === 't' ? 2.5 : 0.6)) damage(m, o.e, o.kind, o.kind === 't' ? dmg * 0.6 : dmg, h); });
  return true;
}
function stepMatch(m) {
  m.tick++;
  if (m.phase === 'pick') {
    const all = m.heroes.every(h => h.locked);
    if (all || Date.now() > m.pickEnd) startGame(m);
    return;
  }
  if (m.over) return;
  m.t += DT; m.waveT -= DT;
  if (m.waveT <= 0) {
    m.waveT = 25;
    for (let t = 0; t < 2; t++) for (let l = 0; l < 3; l++) for (let i = 0; i < 3; i++) {
      const sg = t ? 1 : -1;
      m.minions.push({ id: nextId++, team: t, lane: l, x: sg * (NEXUS_X - 8) - sg * i * 1.6, z: LANES[l], hp: 520 + m.t * 0.6, maxhp: 520 + m.t * 0.6, cd: 0, ranged: i === 2 });
    }
  }
  // hero
  m.heroes.forEach(h => {
    const d = HEROES[h.type];
    for (let i = 0; i < 3; i++) if (h.cd[i] > 0) h.cd[i] -= DT;
    if (h.animT > 0) { h.animT -= DT; if (h.animT <= 0) h.anim = 0; }
    if (!h.alive) { h.respawn -= DT; if (h.respawn <= 0) spawnHero(m, h); return; }
    const base = { x: (h.team ? 1 : -1) * NEXUS_X, z: 0 };
    if (dist(h, base) < 9) h.hp = Math.min(h.maxhp, h.hp + h.maxhp * 0.12 * DT * 4);
    h.hp = Math.min(h.maxhp, h.hp + h.maxhp * 0.004 * DT);
    let dx = 0, dz = 0, spd = d.spd;
    if (!h.bot && h.c) {
      dx = h.c.inp.dx; dz = h.c.inp.dz;
      if (h.want) { useSkill(m, h, h.want - 1); h.want = 0; }
      // auto basic attack bila diam
      if (!dx && !dz && h.cd[0] <= 0) useSkill(m, h, 0);
    } else { const r = botAI(m, h, d); dx = r[0]; dz = r[1]; }
    const l = Math.hypot(dx, dz);
    if (l > 0.05 && h.animT <= 0) {
      dx /= Math.max(1, l); dz /= Math.max(1, l);
      h.x = Math.max(-58, Math.min(58, h.x + dx * spd * DT)); h.z = Math.max(-36, Math.min(36, h.z + dz * spd * DT));
      h.rot = Math.atan2(dz, dx); h.anim = 0; h.moving = true;
    } else h.moving = false;
  });
  // minion
  m.minions.forEach(x => {
    x.cd -= DT;
    const en = enemiesOf(m, x.team); let best = null, bd = 1e9;
    en.forEach(o => { const dd = dist(x, o.e); if (dd < bd) { bd = dd; best = o; } });
    const range = x.ranged ? 6 : 2.2;
    const nearHero = best && bd < 9;
    if (best && bd <= range + (best.kind === 't' ? 2 : 0)) {
      if (x.cd <= 0) { x.cd = 1; damage(m, best.e, best.kind, 38, null); }
    } else {
      let tx, tz;
      if (nearHero && best) { tx = best.e.x; tz = best.e.z; }
      else { const sg = x.team ? -1 : 1; tx = (x.team ? -1 : 1) * NEXUS_X; tz = LANES[x.lane] * Math.max(0, 1 - Math.abs(x.x) / 60) ; if (Math.abs(x.x) < 6) tz = 0; }
      const ang = Math.atan2(tz - x.z, tx - x.x); x.x += Math.cos(ang) * 3.4 * DT; x.z += Math.sin(ang) * 3.4 * DT;
    }
  });
  m.minions = m.minions.filter(x => x.hp > 0);
  // tower
  m.towers.forEach(t => {
    if (t.hp <= 0) return; t.cd -= DT; if (t.cd > 0) return;
    let best = null, bd = 1e9, pri = 9;
    enemiesOf(m, t.team).forEach(o => { if (o.kind === 't') return; const dd = dist(t, o.e); if (dd <= 12 && (o.kind === 'm' ? 0 : 1) <= pri && dd < bd) { if (o.kind === 'm' && pri === 9) pri = 0; bd = dd; best = o; } });
    if (best) { t.cd = 1.1; damage(m, best.e, best.kind, best.kind === 'h' ? 150 + m.t * 0.4 : 220, null); m.fx.push({ id: -1, s: 9, x: t.x, z: t.z, tx: best.e.x, tz: best.e.z, team: t.team }); }
  });
  if (m.tick % 4 === 0) snap(m);
}
function botAI(m, h, d) {
  const sg = h.team ? -1 : 1;
  const base = { x: (h.team ? 1 : -1) * NEXUS_X, z: 0 };
  if (h.hp < h.maxhp * 0.3) { return [base.x - h.x, base.z - h.z]; }
  let best = null, bd = 1e9;
  enemiesOf(m, h.team).forEach(o => { const dd = dist(h, o.e); const w = o.kind === 'h' ? dd * 0.6 : dd; if (dd < 14 && w < bd) { bd = w; best = o; } });
  if (best) {
    const dd = dist(h, best.e); const range = d.sk[0][0] + d.sk[0][1] - 0.3;
    const dxn = best.e.x - h.x, dzn = best.e.z - h.z;
    for (let i = 2; i >= 0; i--) if (h.cd[i] <= 0 && (i === 0 || (best.kind === 'h' && Math.random() < 0.05))) { if (useSkill(m, h, i)) break; }
    if (dd > range) return [dxn, dzn];
    return [0, 0];
  }
  const tx = sg * NEXUS_X; const lz = LANES[h.lane];
  const tz = Math.abs(h.x) < 8 ? 0 : lz * Math.max(0, 1 - Math.abs(h.x) / 58);
  return [tx - h.x, (Math.abs(h.x - tx) > 10 ? tz : 0) - h.z];
}
function snap(m) {
  const msg = {
    t: 'snap', tm: Math.floor(m.t),
    h: m.heroes.map(h => [h.id, +h.x.toFixed(2), +h.z.toFixed(2), +h.rot.toFixed(2), Math.round(h.hp), Math.round(h.maxhp), h.alive ? (h.anim || (h.moving ? 4 : 0)) : 9, h.lvl, h.k, h.d, h.a, Math.ceil(Math.max(0, h.cd[0] * 10)), Math.ceil(Math.max(0, h.cd[1] * 10)), Math.ceil(Math.max(0, h.cd[2] * 10)), Math.ceil(h.respawn > 0 ? h.respawn : 0)]),
    m: m.minions.map(x => [x.id, +x.x.toFixed(1), +x.z.toFixed(1), Math.round(x.hp / x.maxhp * 100), x.team, x.ranged ? 1 : 0]),
    w: m.towers.map(x => [x.id, x.team, x.x, x.z, Math.round(x.hp), x.maxhp, x.nexus ? 1 : 0]),
    fx: m.fx, ev: m.ev,
  };
  m.fx = []; m.ev = [];
  const s = JSON.stringify(msg);
  m.heroes.forEach(h => { if (h.c && h.c.ws.readyState === 1) h.c.ws.send(s); });
}
function endMatch(m, win) {
  if (m.over) return; m.over = true; m.phase = 'end';
  m.heroes.forEach(h => {
    if (!h.c || !h.c.acc) return;
    const a = h.c.acc; const won = h.team === win;
    if (won) a.wins++; else a.losses++;
    let delta = 0;
    if (m.mode === 'rank') { delta = won ? 25 : -15; a.pts = Math.max(0, a.pts + delta); }
    send(h.c, { t: 'end', win, won, delta, mode: m.mode, stats: m.heroes.map(x => ({ id: x.id, name: x.name, team: x.team, type: x.type, k: x.k, d: x.d, a: x.a })) });
    send(h.c, profile(h.c)); h.c.match = null;
  });
  saveDb();
  setTimeout(() => matches.delete(m), 3000);
}
setInterval(() => { for (const m of matches) { try { stepMatch(m); } catch (e) { console.error(e); } } }, DT * 1000);
console.log('Hero Arena server jalan di port', PORT);
